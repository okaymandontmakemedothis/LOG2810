def init():
	global absolute_path_to_working_directory
	absolute_path_to_working_directory = ""
